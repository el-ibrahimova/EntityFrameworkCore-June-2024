﻿using System.Globalization;
using System.Text;
using BookShop.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace BookShop
{
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            // AsNoTracking() -> Detach collection/entity from the Change Tracker
            // Any changes made will not be saved

            // ToArray()/ToList() -> Materialize the query
            // Any code that we write later will not be executed in the DB as SQL
            // The code after materialization is executed locally on the machine in RAM

            using var dbContext = new BookShopContext();
            //   DbInitializer.ResetDatabase(db);

            // 02. string result = GetBooksByAgeRestriction(dbContext, "miNor");
            // 03. string result = GetGoldenBooks(dbContext);
            // 04. string result = GetBooksByPrice(dbContext);
            // 05. string result = GetBooksNotReleasedIn(dbContext, 2000);
            // 06. string result = GetBooksByCategory(dbContext, "horror mystery drama");
            // 07. string result = GetBooksReleasedBefore(dbContext, "30-12-1989");
            // 08. string result = GetAuthorNamesEndingIn(dbContext, "e");

            string result = GetBookTitlesContaining(dbContext, "sK");
            Console.WriteLine(result);

        }

        // 02. Age Restriction

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            try
            {
                AgeRestriction ageRestriction = Enum.Parse<AgeRestriction>(command, true);

                string[] bookTitles = context.Books
                    .Where(b => b.AgeRestriction == ageRestriction)
                    .OrderBy(b => b.Title)
                    .Select(b => b.Title)
                    .ToArray();

                return string.Join(Environment.NewLine, bookTitles);
            }
            catch (Exception e)
            {
                return null;
            }
        }

        // 03. Golden Books

        public static string GetGoldenBooks(BookShopContext context)
        {
            var goldenBooks = context.Books
                .Where(b => b.EditionType == EditionType.Gold && b.Copies < 5000)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToArray();

            return string.Join(Environment.NewLine, goldenBooks);
        }

        // 04. Books By Price
        public static string GetBooksByPrice(BookShopContext context)
        {
            var booksByPrice = context.Books
                .Where(b => b.Price > 40)
                .OrderByDescending(b => b.Price)
                .Select(b => new
                {
                    b.Title,
                    b.Price
                })
                .ToArray();

            StringBuilder sb = new StringBuilder();

            foreach (var b in booksByPrice)
            {
                sb.AppendLine($"{b.Title} - ${b.Price:f2}");
            }

            return sb.ToString().TrimEnd();

        }

        // 05. Not Released In

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var notReleased = context.Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToArray();

            return string.Join(Environment.NewLine, notReleased);
        }

        // 06. Book Titles By Category

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            string[] categories = input.Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(c => c.ToLower())
                .ToArray();

            string[] bookTitles = context.Books
                .Where(b => b.BookCategories.Any(bc => categories.Contains(bc.Category.Name.ToLower())))
                .OrderBy(b => b.Title)
                .Select(b => b.Title)
                .ToArray();

            return string.Join(Environment.NewLine, bookTitles);
        }

        // 07. Released Before Date

        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            // Parse string date to type DateTime
            DateTime dt = DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture);

            var bookReleased = context.Books
                .Where(b => b.ReleaseDate < dt)
                .OrderByDescending(b => b.ReleaseDate)
                .Select(b => $"{b.Title} - {b.EditionType} - ${b.Price:f2}")
                .ToArray();

            return string.Join(Environment.NewLine, bookReleased);
        }

        // 08. Author Search

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            var name = context.Authors
                .Where(a => a.FirstName.EndsWith(input))
                .OrderBy(a=>a.FirstName)
                .ThenBy(a=>a.LastName)
                .Select(a=> $"{a.FirstName} {a.LastName}")
                .ToArray();
            
           return  string.Join(Environment.NewLine, name);
        }

        // 09. Book Search

        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            var bookTitles = context.Books
                .Where(b => b.Title.ToLower().Contains(input.ToLower()))
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToArray();

            return string.Join(Environment.NewLine, bookTitles);
        }
    }
}


