﻿namespace Artillery.Data.Models.Enums
{
    public enum GunType
    {
        Howitzer,
        Mortar,
        FieldGun,
        AntiAircraftGun,
        MountainGun,
        AntiTankGun
    }
}
