﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = "Server=DESKTOP-SENJ7PO\\SQLEXPRESS;Database=Invoices;Integrated Security=True";
    }
}
