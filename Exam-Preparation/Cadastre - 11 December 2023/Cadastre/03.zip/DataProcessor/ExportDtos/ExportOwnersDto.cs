﻿using Cadastre.Data.Enumerations;

namespace Cadastre.DataProcessor.ExportDtos
{
    public class ExportOwnersDto
    {
        public string LastName { get; set; } = null!;
        public string MaritalStatus { get; set; } = null!;
    }
}
