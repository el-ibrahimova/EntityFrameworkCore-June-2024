﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = "Server=DESKTOP-SENJ7PO\\SQLEXPRESS;Database=Theatre;Integrated Security=True";
    }
}
