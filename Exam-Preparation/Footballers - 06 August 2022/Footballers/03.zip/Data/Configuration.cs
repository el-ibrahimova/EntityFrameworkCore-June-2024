﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = "Server=DESKTOP-SENJ7PO\\SQLEXPRESS;Database=FootballersExam;Integrated Security=True";
    }
}
