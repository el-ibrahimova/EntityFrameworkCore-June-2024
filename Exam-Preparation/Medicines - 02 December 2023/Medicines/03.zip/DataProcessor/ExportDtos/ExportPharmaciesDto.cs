﻿namespace Medicines.DataProcessor.ExportDtos
{
    public class ExportPharmaciesDto
    {
        public string Name { get; set; } = null!;
        public string PhoneNumber { get; set; } = null!;
    }
}
