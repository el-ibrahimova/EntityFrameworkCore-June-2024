﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-SENJ7PO\SQLEXPRESS;Database=Medicines;Integrated Security=True";   
    }
}
