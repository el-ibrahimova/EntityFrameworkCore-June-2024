﻿namespace Medicines.Data.Models.Enums
{
    public enum  Gender
    {
        Male = 0,
        Female = 1,
    }
}
