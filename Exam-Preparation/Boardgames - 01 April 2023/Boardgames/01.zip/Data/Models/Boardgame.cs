﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Boardgames.Common;
using Boardgames.Data.Models.Enums;
using Microsoft.EntityFrameworkCore.Storage;

namespace Boardgames.Data.Models
{
    public class Boardgame
    {
        public Boardgame()
        {
            this.BoardgamesSellers = new HashSet<BoardgameSeller>();
        }
        public int Id { get; set; }

        [MaxLength(ValidationConstants.BoardgameNameMaxLength)]
        public string Name { get; set; } = null!;

        [Range(1, 10)]
        public double Rating { get; set; }

        [Range(2018, 2023)]
        public int YearPublished { get; set; }
       
        [Required]
        public CategoryType CategoryType { get; set; }

        public string Mechanics { get; set; } = null!;

        [ForeignKey(nameof(Creator))]
        public int CreatorId { get; set; }
        public virtual Creator Creator {get; set;}

       public virtual ICollection<BoardgameSeller> BoardgamesSellers {get; set;}


    }
}
