﻿namespace Boardgames.Common
{
    public static class ValidationConstants
    {
        // Boardgame
        public const int BoardgameNameMinLength = 10;
        public const int BoardgameNameMaxLength = 20;

        // Seller
        public const int SellerNameMinLength = 5;
        public const int SellerNameMaxLength = 20;
        public const int SellerAddressMinLength = 2;
        public const int SellerAddressMaxLength = 30;
        public const string SellerWebsiteRegex = @"^www\.[A-Za-z0-9-]+\.com$";

        // Creator
        public const int CreatorNameMinLength = 2;
        public const int CreatorNameMaxLength = 7;
    }
}
