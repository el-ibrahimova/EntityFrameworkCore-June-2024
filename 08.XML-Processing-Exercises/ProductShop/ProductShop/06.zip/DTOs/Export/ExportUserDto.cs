﻿using System.Xml.Serialization;
using ProductShop.Models;

namespace ProductShop.DTOs.Export
{
    [XmlType("User")]
    public class ExportUserDto
    {
        [XmlElement("firstName")]
        public string FirstName { get; set; }

        [XmlElement("lastName")]
        public string LastName { get; set; }

        [XmlArray("soldProducts")]
        public ExportProductsDto[] ProductSold { get; set; }
    }


    [XmlType("Product")]
    public class ExportProductsDto
    {
        [XmlElement("name")]
        public string Name { get; set; }

        [XmlElement("price")]
        public decimal Price { get; set; }
    }


}
