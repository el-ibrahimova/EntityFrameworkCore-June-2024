﻿using System.Reflection.Metadata;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            ProductShopContext dBcontext = new ProductShopContext();

            //  01.
            //  string usersJson = File.ReadAllText("../../../Datasets/users.json");
            //  Console.WriteLine(ImportUsers(dBcontext, usersJson));


            // 02.  
            // string productsJson = File.ReadAllText("../../../Datasets/products.json");
            // Console.WriteLine(ImportProducts(dBcontext, productsJson));

            // 03. 
            // string categoriesJson = File.ReadAllText("../../../Datasets/categories.json");
            // Console.WriteLine(ImportCategories(dBcontext, categoriesJson));

            // 04.
             string catProdJson = File.ReadAllText("../../../Datasets/categories-products.json");
             Console.WriteLine(ImportCategoryProducts(dBcontext, catProdJson));
        }


        // 01. Import Users
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            var users = JsonConvert.DeserializeObject<User[]>(inputJson);

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Length}";
        }

        // 02. Import Products
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            var products = JsonConvert.DeserializeObject<Product[]>(inputJson);

            if (products != null)
            {
                context.Products.AddRange(products);
                context.SaveChanges();
            }

            return $"Successfully imported {products.Length}";
        }

        // 03. Import Categories
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            var allCategories = JsonConvert.DeserializeObject<Category[]>(inputJson);

            var validCategories = allCategories?
                .Where(c => c.Name != null)
                .ToArray();

            if (validCategories == null)
            {
                return $"Successfully imported 0";
            }

            context.Categories.AddRange(validCategories);
            context.SaveChanges();
            return $"Successfully imported {validCategories.Length}";
        }

        // 04. Import Categories and Products
        public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
        {
            var categoriesProducts = JsonConvert.DeserializeObject<CategoryProduct[]>(inputJson);

            context.CategoriesProducts.AddRange(categoriesProducts);
            context.SaveChanges();

            return $"Successfully imported {categoriesProducts.Length}";
        }
    }
}
