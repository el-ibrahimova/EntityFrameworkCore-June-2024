﻿using System.Linq.Expressions;
using System.Reflection.Metadata.Ecma335;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            CarDealerContext dBcontext = new CarDealerContext();

            // 09
            // string jsonSuppliers = File.ReadAllText("../../../Datasets/suppliers.json");
            // Console.WriteLine(ImportSuppliers(dBcontext,jsonSuppliers));

            // 10
            // string jsonParts = File.ReadAllText("../../../Datasets/parts.json");
            // Console.WriteLine(ImportParts(dBcontext, jsonParts));

            // 11
            // string jsonCars = File.ReadAllText("../../../Datasets/cars.json");
            // Console.WriteLine(ImportCars(dBcontext, jsonCars));

            // 12
            string jsonCustomers = File.ReadAllText("../../../Datasets/customers.json");
            Console.WriteLine(ImportCustomers(dBcontext, jsonCustomers));

        }

        // 09. Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliers = JsonConvert.DeserializeObject<Supplier[]>(inputJson);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}.";
        }

        // 10. Import parts
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var parts = JsonConvert.DeserializeObject<Part[]>(inputJson);

            int[] supplierIds = context.Suppliers.Select(x => x.Id).ToArray();

            var validParts = parts.Where(p => supplierIds.Contains(p.SupplierId)).ToArray();

            context.Parts.AddRange(validParts);
            context.SaveChanges();

            return $"Successfully imported {validParts.Count()}.";
        }

        // 11. Import Cars
        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var carsDtos = JsonConvert.DeserializeObject<ImportCarDto[]>(inputJson);

            var cars = new HashSet<Car>();
            var partsCars = new HashSet<PartCar>();

            foreach (var carDto in carsDtos)
            {
                var newCar = new Car()
                {
                    Make = carDto.Make,
                    Model = carDto.Model,
                    TraveledDistance = carDto.TraveledDistance
                };

                cars.Add(newCar);

                foreach (var partId in carDto.PartsId.Distinct()) // Distinct = only unique values
                {
                    partsCars.Add(new PartCar()
                    {
                        Car = newCar,
                        PartId = partId
                    });
                }
            }

            context.Cars.AddRange(cars);
            context.PartsCars.AddRange(partsCars);

            context.SaveChanges();

            return $"Successfully imported {cars.Count()}.";

        }

        // 12. Import Customers
        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            var customers = JsonConvert.DeserializeObject<Customer[]>(inputJson);

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count()}.";
        }
    }
}